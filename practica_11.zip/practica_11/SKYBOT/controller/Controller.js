const db = require("../config/db");

module.exports = {

    obtenerCategorias: (req, res) => {
        db.query("SELECT * FROM categorias", (err, rows) => {
            if (err) return res.status(500).json(err);
            res.json(rows);
        });
    },

    crearCategoria: (req, res) => {
        const { nombre } = req.body;

        db.query("INSERT INTO categorias SET ?", { nombre }, (err) => {
            if (err) return res.status(500).json(err);
            res.json({ mensaje: "Categoría creada" });
        });
    },

    actualizarCategoria: (req, res) => {
        const { id } = req.params;
        const { nombre } = req.body;

        db.query(
            "UPDATE categorias SET nombre = ? WHERE id = ?",
            [nombre, id],
            (err) => {
                if (err) return res.status(500).json(err);
                res.json({ mensaje: "Categoría actualizada" });
            }
        );
    },

    eliminarCategoria: (req, res) => {
        const { id } = req.params;

        db.query("DELETE FROM categorias WHERE id = ?", [id], (err) => {
            if (err) return res.status(500).json(err);
            res.json({ mensaje: "Categoría eliminada" });
        });
    }

};
