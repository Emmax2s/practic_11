const db = require("../config/db");

module.exports = {

    obtenerProductos: (req, res) => {
        db.query("SELECT * FROM productos", (err, rows) => {
            if (err) return res.status(500).json({ error: err });
            res.json(rows);
        });
    },

    crearProducto: (req, res) => {
        const { nombre, descripcion, precio, stock, categoria_id } = req.body;

        if (!nombre || !precio) {
            return res.status(400).json({ error: "Nombre y precio son obligatorios" });
        }

        const nuevoProducto = { nombre, descripcion, precio, stock, categoria_id };

        db.query("INSERT INTO productos SET ?", nuevoProducto, (err) => {
            if (err) return res.status(500).json({ error: err });
            res.json({ mensaje: "Producto creado correctamente" });
        });
    },

    actualizarProducto: (req, res) => {
        const { id } = req.params;
        const { nombre, descripcion, precio, stock, categoria_id } = req.body;

        db.query(
            "UPDATE productos SET nombre=?, descripcion=?, precio=?, stock=?, categoria_id=? WHERE id=?",
            [nombre, descripcion, precio, stock, categoria_id, id],
            (err) => {
                if (err) return res.status(500).json({ error: err });
                res.json({ mensaje: "Producto actualizado correctamente" });
            }
        );
    },

    eliminarProducto: (req, res) => {
        const { id } = req.params;

        db.query("DELETE FROM productos WHERE id = ?", [id], (err) => {
            if (err) return res.status(500).json({ error: err });
            res.json({ mensaje: "Producto eliminado" });
        });
    }

};
