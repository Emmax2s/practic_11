const db = require("../config/db");

module.exports = {
    login: (req, res) => {
        const { correo, password } = req.body;

        const query = "SELECT id, nombre, rol FROM usuarios WHERE correo = ? AND password = ?";

        db.query(query, [correo, password], (err, rows) => {
            if (err) return res.status(500).json({ error: err });

            if (rows.length > 0) {
                res.json({
                    success: true,
                    message: "Login correcto",
                    user: rows[0]
                });
            } else {
                res.json({
                    success: false,
                    message: "Correo o contraseña incorrectos"
                });
            }
        });
    }
};
