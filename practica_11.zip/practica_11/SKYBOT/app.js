const express = require('express');
const morgan = require('morgan');
const app = express();

// Middlewares
app.use(morgan('dev'));
app.use(express.json());

// Rutas del proyecto
const categoriaRoutes = require('./routes/categoriaRoutes');
const productoRoutes = require('./routes/productoRoutes');
const usuarioRoutes = require('./routes/usuarioRoutes');

// Ruta principal
app.get('/', (req, res) => {
  res.send('Servidor SKYBOT funcionando correctamente');
});

// Prefijos para acceder a cada módulo
app.use('/admin/categorias', categoriaRoutes);
app.use('/admin/productos', productoRoutes);
app.use('/admin/usuarios', usuarioRoutes);

// Ejecutar servidor
app.listen(8080, () => {
  console.log('Servidor corriendo en http://localhost:8080');
});
