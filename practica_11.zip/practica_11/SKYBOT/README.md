
SkyBot es una página web dedicada a la venta de componentes electrónicos.  
Este proyecto utiliza **Node.js**, **Express** y **MySQL** para gestionar productos, clientes, pedidos y pagos.

---


Si lo estás clonando desde GitHub:

git clone C:\Users\emaxi\OneDrive\Documentos\GitHub\skybot

🧩 2. Instalar dependencias

Desde la carpeta del proyecto, ejecuta en la terminal:

npm install


Esto instalará:

express

mysql

express-myconnection

morgan

nodemon

🗃️ 3. Crear la base de datos

Abre MySQL Workbench o la terminal de MySQL.

Ejecuta el script llamado dbskybot.sql que se encuentra en la carpeta /db.

Esto creará:

La base de datos dbskybot

El usuario dbskybot con contraseña 12345

Las tablas usuarios, productos, categorias, clientes, pedidos, detalle_pedido, pagos

⚙️ 4. Configurar la conexión en app.js

El archivo app.js ya contiene la configuración:

user: 'dbskybot',
password: '12345',
database: 'dbskybot',
host: 'localhost',
port: 3306


Asegúrate de que el servidor MySQL esté iniciado antes de ejecutar el proyecto.

▶️ 5. Ejecutar el servidor

Para iniciar el servidor manualmente:

node app.js


O con reinicio automático (recomendado):

npx nodemon app.js
